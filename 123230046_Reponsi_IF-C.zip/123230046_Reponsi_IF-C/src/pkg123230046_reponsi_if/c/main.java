/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg123230046_reponsi_if.c;

import View.DashboardPage;

/**
 *
 * @author Lab Informatika
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        DashboardPage dashboardpage = new DashboardPage();
        dashboardpage.setVisible(true);
        dashboardpage.setLocationRelativeTo(null);
    }
    
}
